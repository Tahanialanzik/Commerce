
<?php $__env->startSection('title'); ?>
<title>تفاصيل منتج  <?php echo e($product->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headertitle'); ?>
<h1> <?php echo e($product->name); ?></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Product Details</div>
                    <div class="card-body">
                        <p><strong>Name:</strong> <?php echo e($product->name); ?></p>
                        <p><strong>Description:</strong> <?php echo e($product->description); ?></p>
                        <p><strong>Price:</strong> <?php echo e($product->price); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Commerce\resources\views/products/show.blade.php ENDPATH**/ ?>