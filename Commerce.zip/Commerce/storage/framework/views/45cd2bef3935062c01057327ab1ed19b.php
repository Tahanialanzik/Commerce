

<?php $__env->startSection('title'); ?>
<title>المنتجات</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headertitle'); ?>
<h1>المنتجات</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row justify-content-center" -5>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Products</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('products.index')); ?>" method="GET">
                            <div class="form-group">
                                <input type="text" name="search" class="form-control" placeholder="Search products...">
                            </div>
                            <button type="submit" class="btn btn-primary">Search</button>
                        </form>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><?php echo e($product->price); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info">View</a>
                                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary">Edit</a>
                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">Add Product</a><a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Show All</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Commerce\resources\views/products/index.blade.php ENDPATH**/ ?>